#include "ofApp.h"

int main() {
    ofSetupOpenGL(RES_WIDTH, RES_HEIGHT, OF_WINDOW);
    ofRunApp(new ofApp());   
}
